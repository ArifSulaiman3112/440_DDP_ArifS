#include <iostream>
using namespace std;

int main(){
    int baris, kolom, baris_atas;

    cout<<"masukkan garis atas : ";
    cin>>baris_atas;

    cout<<"masukkan baris : ";
    cin>>baris;

    cout<<"masukkan kolom : ";
    cin>>kolom;

    for(int ba= 1; ba<=baris_atas; ba++){cout<<" ___ ";
    }
    cout<<endl;

    for(int brs= 1; brs<=baris; brs++){
        for(int klm=1; klm <=kolom; klm++){
            cout<<"|___|";
        }
        cout<<endl;
    }
    return 0;
}