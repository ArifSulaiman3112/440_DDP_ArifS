#include <iostream>
using namespace std;

int main(){
    int baris, kolom, atas;

    cout<<"masukkan garis atas : ";
    cin>>atas;

    cout<<"masukkan baris : ";
    cin>>baris;

    cout<<"masukkan kolom : ";
    cin>>kolom;

    for(int c= 1; c<=baris; c++){cout<<" ___ ";
    }
    cout<<endl;

    for(int a= 1; a<=baris; a++){
        for(int b=1; b <=kolom; b++){
            cout<<"|___|";
        }
        cout<<endl;
    }
    return 0;
}